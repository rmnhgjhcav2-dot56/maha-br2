import React, { useState } from "react";
import { auth } from "../firebase";
import { signInWithEmailAndPassword } from "firebase/auth";

/**
 * Deliberately minimal: this boutique app has no public sign-up screen.
 * Create one Firebase Auth account per staff member from the Firebase
 * Console (Authentication → Users → Add user) — see README "Auth" section.
 * All signed-in accounts share the same Firestore data (see firestore.rules).
 */
export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await signInWithEmailAndPassword(auth, email.trim(), password);
    } catch (err) {
      setError("بيانات الدخول غير صحيحة، حاولي مرة ثانية.");
    }
    setLoading(false);
  };

  return (
    <div style={{
      minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center",
      background: "#FAF3EF", fontFamily: "Tajawal, sans-serif", direction: "rtl", padding: 20,
    }}>
      <form onSubmit={submit} style={{
        background: "#fff", border: "1px solid #E8DDD6", borderRadius: 18, padding: 28,
        width: "100%", maxWidth: 360,
      }}>
        <h1 style={{ fontFamily: "Markazi Text, serif", fontSize: 30, color: "#4A1329", margin: "0 0 6px" }}>
          ✨ بوتيك العرايس
        </h1>
        <p style={{ fontSize: 13, color: "#8A7A6E", margin: "0 0 20px" }}>سجّلي الدخول لمتابعة العميلات</p>

        <label style={{ display: "block", fontSize: 12, color: "#8A7A6E", marginBottom: 5, fontWeight: 600 }}>البريد الإلكتروني</label>
        <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)}
          style={{ width: "100%", border: "1px solid #E8DDD6", borderRadius: 10, padding: 11, marginBottom: 14, fontSize: 15 }} />

        <label style={{ display: "block", fontSize: 12, color: "#8A7A6E", marginBottom: 5, fontWeight: 600 }}>كلمة المرور</label>
        <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)}
          style={{ width: "100%", border: "1px solid #E8DDD6", borderRadius: 10, padding: 11, marginBottom: 14, fontSize: 15 }} />

        {error && <div style={{ color: "#B23B3B", fontSize: 13, marginBottom: 12 }}>{error}</div>}

        <button type="submit" disabled={loading} style={{
          width: "100%", background: "#6B1E3C", color: "#FBEFE9", border: "none", borderRadius: 11,
          padding: 12, fontSize: 15, fontWeight: 700, cursor: "pointer",
        }}>
          {loading ? "جارِ الدخول..." : "دخول"}
        </button>
      </form>
    </div>
  );
}
