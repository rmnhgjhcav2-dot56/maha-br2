import React, { useEffect, useState } from "react";
import { onAuthStateChanged, signOut } from "firebase/auth";
import { auth } from "./firebase";
import Login from "./auth/Login.jsx";
import BridalApp from "./components/BridalApp.jsx";

export default function App() {
  // undefined = still checking session, null = signed out, object = signed in
  const [user, setUser] = useState(undefined);

  useEffect(() => onAuthStateChanged(auth, setUser), []);

  if (user === undefined) {
    return (
      <div style={{
        minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center",
        fontFamily: "Tajawal, sans-serif", color: "#6B1E3C",
      }}>
        جارِ التحقق من الجلسة...
      </div>
    );
  }

  if (!user) return <Login />;

  return <BridalApp user={user} onSignOut={() => signOut(auth)} />;
}
