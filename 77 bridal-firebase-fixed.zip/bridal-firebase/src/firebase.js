import { initializeApp } from "firebase/app";
import {
  initializeFirestore,
  persistentLocalCache,
  persistentMultipleTabManager,
} from "firebase/firestore";
import { getAuth } from "firebase/auth";
import { getStorage } from "firebase/storage";
import { getFunctions } from "firebase/functions";

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};

if (!firebaseConfig.apiKey) {
  // Loud, obvious failure instead of a silent blank screen if .env.local is missing.
  // eslint-disable-next-line no-console
  console.error(
    "Firebase config is empty. Copy .env.example to .env.local and fill in your project's web config."
  );
}

export const app = initializeApp(firebaseConfig);

// Modern offline-persistence API (replaces the deprecated
// enableIndexedDbPersistence). persistentMultipleTabManager lets the same
// browser have more than one tab open on the app without persistence
// erroring out; each of the 4-5 phones is its own separate browser/IndexedDB
// so they don't need tab coordination with each other — sync between DEVICES
// happens through Firestore's normal server sync + onSnapshot listeners,
// this local cache only covers a single device working offline.
export const db = initializeFirestore(app, {
  localCache: persistentLocalCache({
    tabManager: persistentMultipleTabManager(),
  }),
});

export const auth = getAuth(app);
export const storage = getStorage(app);
export const functions = getFunctions(app);
