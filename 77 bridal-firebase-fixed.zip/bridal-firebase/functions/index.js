/**
 * Cloud Function: reviewCustomerData
 *
 * The ONLY place in the whole project that calls the Anthropic API.
 * The API key lives in Secret Manager and is never sent to the browser.
 * The frontend calls this function through Firebase SDK (httpsCallable).
 */

const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");
const admin = require("firebase-admin");

admin.initializeApp();

const db = admin.firestore();
const { FieldValue } = admin.firestore;

const ANTHROPIC_API_KEY = defineSecret("ANTHROPIC_API_KEY");

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

function finalPrice(bride) {
  const total = Number(bride?.finance?.totalPrice) || 0;
  const discount = Number(bride?.finance?.discount) || 0;
  return Math.max(total - discount, 0);
}

function collected(bride) {
  const deposit = Number(bride?.finance?.deposit) || 0;
  const payments = Array.isArray(bride?.finance?.payments)
    ? bride.finance.payments
    : [];

  const extra = payments.reduce(
    (sum, payment) => sum + (Number(payment?.amount) || 0),
    0
  );

  return deposit + extra;
}

function remaining(bride) {
  return Math.max(finalPrice(bride) - collected(bride), 0);
}

function buildCompactCustomer(bride, id) {
  const payments = Array.isArray(bride?.finance?.payments)
    ? bride.finance.payments
    : [];

  return {
    id,
    name: bride?.name || "بدون اسم",
    wedding_date: bride?.wedding?.date || null,
    delivery_agreed: bride?.deliveryAgreed || null,
    delivery_actual: bride?.deliveryActual || null,
    production_stage: bride?.productionStage || "not_started",
    total_after_discount: finalPrice(bride),
    deposit: Number(bride?.finance?.deposit) || 0,
    extra_payments_total: payments.reduce(
      (sum, payment) => sum + (Number(payment?.amount) || 0),
      0
    ),
    remaining: remaining(bride),
  };
}

exports.reviewCustomerData = onCall(
  {
    secrets: [ANTHROPIC_API_KEY],
    region: "us-central1",
  },
  async (request) => {
    if (!request.auth) {
      throw new HttpsError(
        "unauthenticated",
        "يجب تسجيل الدخول أولاً."
      );
    }

    const apiKey = ANTHROPIC_API_KEY.value();

    if (!apiKey) {
      console.error("ANTHROPIC_API_KEY is not configured.");
      throw new HttpsError(
        "failed-precondition",
        "مفتاح خدمة الذكاء الاصطناعي غير مُعد في Secret Manager."
      );
    }

    let snap;

    try {
      snap = await db.collection("customers").get();
    } catch (err) {
      console.error("Firestore customers read failed:", err);
      throw new HttpsError(
        "internal",
        "تعذّر قراءة بيانات العملاء من قاعدة البيانات."
      );
    }

    const today = todayStr();

    const compact = snap.docs.map((doc) =>
      buildCompactCustomer(doc.data(), doc.id)
    );

    const prompt = `اليوم هو ${today}. هذه بيانات عرايس بوتيك فساتين زفاف بصيغة JSON:
${JSON.stringify(compact)}

راجعي البيانات وأرجعي فقط مصفوفة JSON صافية (بدون أي نص خارجها ولا Markdown) لتنبيهات مهمة لصاحبة البوتيك، كل عنصر بهذا الشكل بالضبط:
{"bride_id":"...","bride_name":"...","severity":"high","message":"جملة عربية قصيرة وواضحة وودودة"}

severity تكون واحدة فقط من: high, medium, info.

انتبهي تحديداً إلى:
1) فساتين موعد تسليمها المتفق عليه خلال 3 أيام أو أقل من اليوم ولم تُسلَّم بعد (تأخير أو اقتراب) — severity: high إذا يوم واحد أو أقل أو فات الموعد، وإلا medium.
2) أي تناقض أو خطأ حسابي محتمل: deposit + extra_payments_total أكبر من total_after_discount، أو remaining لا يطابق total_after_discount - deposit - extra_payments_total، أو أرقام سالبة أو صفرية غير منطقية مع وجود دفعات.
3) فستان وصل لمرحلة "done" (تم الانتهاء) لكن delivery_agreed فاضي.
4) موعد زواج خلال 7 أيام والمرحلة لا تزال "not_started".
5) موعد زواج مضى (قبل اليوم) والفستان لا يزال غير مُسلَّم.
6) لا تنشئي تنبيهاً لمعلومة ناقصة فقط إذا لم توجد أدلة كافية على وجود مشكلة.

إذا لم توجد أي ملاحظة مهمة، أرجعي [].
لا تكتبي أي شيء غير المصفوفة نفسها.`;

    let alerts = [];

    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": apiKey,
          "anthropic-version": "2023-06-01",
        },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 1200,
          messages: [
            {
              role: "user",
              content: prompt,
            },
          ],
        }),
      });

      const responseText = await response.text();

      if (!response.ok) {
        console.error(
          `Anthropic API ${response.status}:`,
          responseText.slice(0, 2000)
        );
        throw new Error(`Anthropic API ${response.status}`);
      }

      let data;

      try {
        data = JSON.parse(responseText);
      } catch (err) {
        console.error(
          "Invalid Anthropic response JSON:",
          responseText.slice(0, 2000)
        );
        throw new Error("Invalid Anthropic response");
      }

      const text = Array.isArray(data?.content)
        ? data.content
            .filter((item) => item?.type === "text")
            .map((item) => item.text || "")
            .join("\n")
            .trim()
        : "";

      if (!text) {
        throw new Error("Anthropic returned an empty response");
      }

      const clean = text
        .replace(/^```json\s*/i, "")
        .replace(/^```\s*/i, "")
        .replace(/\s*```$/i, "")
        .trim();

      const parsed = JSON.parse(clean);

      if (!Array.isArray(parsed)) {
        throw new Error("AI response is not an array");
      }

      alerts = parsed
        .filter(
          (item) =>
            item &&
            typeof item === "object" &&
            typeof item.bride_id === "string" &&
            typeof item.bride_name === "string" &&
            ["high", "medium", "info"].includes(item.severity) &&
            typeof item.message === "string"
        )
        .map((item) => ({
          bride_id: item.bride_id,
          bride_name: item.bride_name,
          severity: item.severity,
          message: item.message.trim(),
        }));
    } catch (err) {
      console.error("reviewCustomerData failed:", err);
      throw new HttpsError(
        "internal",
        "تعذّر الاتصال بخدمة المراجعة الذكية."
      );
    }

    try {
      await db.collection("system").doc("aiReview").set({
        alerts,
        checkedAt: FieldValue.serverTimestamp(),
      });

      return {
        alerts,
        checkedAt: Date.now(),
      };
    } catch (err) {
      console.error("Firestore aiReview write failed:", err);
      throw new HttpsError(
        "internal",
        "تمت المراجعة الذكية لكن تعذّر حفظ النتيجة."
      );
    }
  }
);
